<%@ page import="java.sql.*"%>
<%@ page import="java.util.*"%>
<%
	Class.forName("com.mysql.jdbc.Driver");
   	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/centrosaudejsp","root","");  
   //coneccao
   
%>
