-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 23-Jun-2017 às 16:08
-- Versão do servidor: 10.1.10-MariaDB
-- PHP Version: 7.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `centrosaudejsp`
--
CREATE DATABASE IF NOT EXISTS `centrosaudejsp` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `centrosaudejsp`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `marcacao`
--

CREATE TABLE `marcacao` (
  `id_marcacao` int(11) NOT NULL,
  `paciente` varchar(40) NOT NULL,
  `profissional` varchar(40) NOT NULL,
  `horas` time NOT NULL,
  `data` date NOT NULL,
  `estado` tinyint(4) NOT NULL,
  `tipo_marcacao` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `premarcacao`
--

CREATE TABLE `premarcacao` (
  `id_marcacao` int(11) NOT NULL,
  `paciente` varchar(40) NOT NULL,
  `profissional` varchar(40) NOT NULL,
  `horas` time NOT NULL,
  `data` date NOT NULL,
  `estado` tinyint(4) NOT NULL,
  `tipo_marcacao` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_utilizador`
--

CREATE TABLE `tipo_utilizador` (
  `idTipoUtilizador` int(11) NOT NULL,
  `descricao` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tipo_utilizador`
--

INSERT INTO `tipo_utilizador` (`idTipoUtilizador`, `descricao`) VALUES
(1, 'admin'),
(2, 'medico'),
(3, 'utente');

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizador`
--

CREATE TABLE `utilizador` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `morada` varchar(30) NOT NULL,
  `telemovel` int(9) NOT NULL,
  `dataNascimento` date NOT NULL,
  `naturalidade` varchar(30) NOT NULL,
  `nacionalidade` varchar(30) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `tipoUtilizador` int(11) NOT NULL,
  `estado` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `utilizador`
--

INSERT INTO `utilizador` (`username`, `password`, `morada`, `telemovel`, `dataNascimento`, `naturalidade`, `nacionalidade`, `email`, `tipoUtilizador`, `estado`) VALUES
('admin', 'admin', 'Rua A', 966666666, '2017-05-26', 'Silvares', 'Portugal', 'admin@admin.pt', 1, 1),
('admin2', 'admin2', 'Rua z', 999999999, '2017-06-22', 'Silvares', 'Portugal', 'vasco.ponciano@facebook.com', 1, 1),
('admin3', 'admin3', 'Rua h', 969733333, '2017-06-14', 'Silvares', 'Portugal', 'vasco.ponciano@facebook.com', 1, 1),
('medico', 'medico', 'rua c', 9856, '2017-06-21', 'cb', 'cb', 'ana.sofia.y96@gmail.com', 2, 1),
('medico2', 'medico2', 'Rua h', 969733333, '2017-06-08', 'Fundao', 'Portugal', 'vasco.ponciano@facebook.com', 2, 1),
('medico3', 'medico3', 'Rua h', 969733333, '2017-06-08', 'Silvares', 'Portugal', 'vasco.ponciano@facebook.com', 2, 1),
('utente', 'utente', 'rua c', 962587788, '2017-06-05', 'cb', 'cb', 'utente@utente.pt', 3, 1),
('utente2', 'utente2', 'Rua E', 969733333, '2017-06-15', 'Silvares', 'Portugal', 'vasco.ponciano@facebook.com', 3, 1),
('utente3', 'utente3', 'Rua hhhh', 969733333, '2017-06-15', 'Silvares', 'Portugal', 'vasco.ponciano@facebook.com', 3, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `marcacao`
--
ALTER TABLE `marcacao`
  ADD PRIMARY KEY (`id_marcacao`),
  ADD KEY `id_marcacao_fk` (`id_marcacao`);

--
-- Indexes for table `premarcacao`
--
ALTER TABLE `premarcacao`
  ADD PRIMARY KEY (`id_marcacao`),
  ADD KEY `id_marcacao` (`id_marcacao`);

--
-- Indexes for table `tipo_utilizador`
--
ALTER TABLE `tipo_utilizador`
  ADD PRIMARY KEY (`idTipoUtilizador`);

--
-- Indexes for table `utilizador`
--
ALTER TABLE `utilizador`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `username_2` (`username`),
  ADD KEY `tipoUtilizador_fk` (`tipoUtilizador`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `marcacao`
--
ALTER TABLE `marcacao`
  MODIFY `id_marcacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `premarcacao`
--
ALTER TABLE `premarcacao`
  MODIFY `id_marcacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
